package edu.uao.project.backend.refugios;

import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class RefugioService {

    private final RefugioRepositorio refugioRepo;

    public void crearRefugio(Refugio refugio)
    {
        refugioRepo.save(refugio);
    
    }
    
    public Refugio findById(Integer id_refugio) {
        return refugioRepo.findById(id_refugio).orElse(null);
    }

    public void deleteById(Integer id_refugio) {
        refugioRepo.deleteById(id_refugio);
    }

    public void actualizarRefugio(Integer id_refugio, Refugio refugioNuevo) {
        Refugio refugioExistente = refugioRepo.findById(id_refugio).orElse(null);
        if (refugioExistente != null) {
            refugioExistente.setNombre(refugioNuevo.getNombre());
            refugioExistente.setCiudad(refugioNuevo.getCiudad());
            refugioExistente.setDireccion(refugioNuevo.getDireccion());
            refugioExistente.setCapacidad(refugioNuevo.getCapacidad());
            refugioRepo.save(refugioExistente);
        }
    }

}
 