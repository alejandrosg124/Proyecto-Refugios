package edu.uao.project.backend.refugios;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import lombok.RequiredArgsConstructor;


@RestController
@RequestMapping("/refugio")
@RequiredArgsConstructor
public class RefugioController {
    
    private final RefugioService refugioService;

    @PostMapping
    public void crearRefugio(@RequestBody Refugio refugio)
    {
        refugioService.crearRefugio(refugio);
    }

    @GetMapping("/{id_refugio}")
    public Refugio findById(@PathVariable Integer id_refugio)
    {
        return refugioService.findById(id_refugio);
    }

    @PutMapping("/{id_refugio}")
    public void actualizarRefugio(@PathVariable Integer id_refugio, @RequestBody Refugio refugioNuevo)
    {
        refugioService.actualizarRefugio(id_refugio, refugioNuevo);
    }

    @DeleteMapping("/{id_refugio}")
    public void eliminarRefugio(@PathVariable Integer id_refugio)
    {
        refugioService.deleteById(id_refugio);
    }

}