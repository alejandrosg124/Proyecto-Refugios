package edu.uao.project.backend.refugios;

import jakarta.persistence.Basic;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Refugio {
    @Id
    @GeneratedValue
    private Integer id_refugio;
    @Basic
    private String nombre;
    private String ciudad;
    private String direccion;
    private Integer capacidad;

}
